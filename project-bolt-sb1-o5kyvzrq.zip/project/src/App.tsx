import React, { useState } from 'react';
import { Search, ShoppingCart, Headphones, Sprout } from 'lucide-react';
import NameEntry from './components/NameEntry';
import Store from './components/Store';
import Cart from './components/Cart';
import CustomerSupport from './components/CustomerSupport';

function App() {
  const [customerName, setCustomerName] = useState('');
  const [showStore, setShowStore] = useState(false);
  const [cart, setCart] = useState<Array<{ id: number; name: string; price: number; quantity: number }>>([]);
  const [showCart, setShowCart] = useState(false);
  const [showSupport, setShowSupport] = useState(false);

  const addToCart = (product: { id: number; name: string; price: number }) => {
    setCart(prevCart => {
      const existingProduct = prevCart.find(item => item.id === product.id);
      if (existingProduct) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });
  };

  if (!customerName) {
    return <NameEntry onSubmit={setCustomerName} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className="bg-green-700 text-white p-4 shadow-lg">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sprout className="h-6 w-6" />
            <span className="text-xl font-bold">AGRIHUB</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <span className="text-lg">Welcome, {customerName}</span>
            <div className="relative">
              <input
                type="search"
                placeholder="Search products..."
                className="px-4 py-2 rounded-full text-gray-800 w-64"
              />
              <Search className="absolute right-3 top-2.5 h-5 w-5 text-gray-500" />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowCart(true)}
              className="flex items-center space-x-1 hover:text-green-200"
            >
              <ShoppingCart className="h-6 w-6" />
              <span className="bg-white text-green-700 rounded-full px-2 py-1 text-sm">
                {cart.reduce((acc, item) => acc + item.quantity, 0)}
              </span>
            </button>
            <button
              onClick={() => setShowSupport(true)}
              className="hover:text-green-200"
            >
              <Headphones className="h-6 w-6" />
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto py-8">
        <Store addToCart={addToCart} />
      </main>

      {/* Cart Modal */}
      {showCart && (
        <Cart
          items={cart}
          onClose={() => setShowCart(false)}
          setCart={setCart}
        />
      )}

      {/* Customer Support Modal */}
      {showSupport && (
        <CustomerSupport onClose={() => setShowSupport(false)} />
      )}
    </div>
  );
}

export default App;