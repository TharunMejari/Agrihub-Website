export const products = [
  {
    id: 1,
    name: "Wheat  Seeds bag",
    description: "High-quality seeds for wheat crop",
    price: 599,
    image: "https://www.bombaysuperseeds.com/images/prod/wheat/bombay-701.webp",
    category: "seeds"
  },
  {
    id: 2,
    name: "Organic Plant Growth Fertilizer",
    description: "Natural fertilizer for better crop yield",
    price: 499,
    image: "https://shehrikisaan.com/wp-content/uploads/2023/06/Plant-Magic.jpg",
    category: "fertilizers"
  },
  {
    id: 3,
    name: "Natural Pest Control Spray",
    description: "Eco-friendly pesticide for garden protection",
    price: 349,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNggEgAb6ogLUhdYWJQVKeUqq4JgBu31eLrQ&s",
    category: "pesticides"
  },
  {
    id: 4,
    name: "Hybrid Tomato Seeds",
    description: "Disease-resistant tomato variety",
    price: 149,
    image: "https://images.unsplash.com/photo-1592841200221-a6898f307baa",
    category: "seeds"
  },
  {
    id: 5,
    name: "Rice seeds -25kg",
    description: "Good quality seeds for better crops",
    price: 1499,
    image: "https://img500.exportersindia.com/product_images/bc-500/2024/5/2075913/paddy-seed-1715343656-7422252.jpg",
    category: "seeds"
  },
  {
    id: 6,
    name: "insecticide",
    description: "best pesticide for insects",
    price: 299,
    image: "https://plantlane.com/cdn/shop/products/Attack_5.jpg?v=1681738316",
    category: "pesticides"
  },
  {
    id: 7,
    name: "Pesti Guard",
    description: "Disease-resistant pesticide",
    price: 450,
    image: "https://cdn.moglix.com/p/ALnrsWgqC7yVm-xxlarge.jpg",
    category: "pesticides"
  },
  {
    id: 8,
    name: "Bio finish",
    description: "Bio pesticide for curing pests",
    price: 199,
    image: "https://cdn.shopify.com/s/files/1/0722/2059/files/bio-finish-bio-pesticide-file-6964.webp?v=1737472790",
    category: "pesticides"
  },
  {
    id: 9,
    name: "BABA Bio pesticide",
    description: "Bio pesticide for curing pests",
    price: 359,
    image: "https://www.agriplexindia.com/cdn/shop/products/Multiplex-Baba_2.png?crop=center&height=645&v=1691064974&width=645",
    category: "pesticides"
  },
  {
    id: 10,
    name: "Super 4000 killer",
    description: "Bio pesticide for curing pests and insects",
    price: 399,
    image: "https://5.imimg.com/data5/SELLER/Default/2023/10/351796735/NJ/QR/DN/7785409/synthetic-pesticides-500x500.jpeg",
    category: "pesticides"
  },
  {
    id: 11,
    name: "Hybrid corn seeds",
    description: "corn seeds for good crops",
    price: 499,
    image: "https://tiimg.tistatic.com/fp/1/007/977/99-percent-pure-organic-a-grade-hybrid-corn-32d12-seeds-452.jpg",
    category: "seeds"
  },
  {
    id: 12,
    name: "kiladi cotton seeds",
    description: "hogh quality seeds for cotton crop",
    price: 329,
    image: "https://sreemohanagrimall.com/cdn/shop/files/Khilidi.jpg?v=1684137548",
    category: "seeds"
  },
  {
    id: 13,
    name: "ground nut seeds-25 kg",
    description: "best quality ground nut seeds for high quality",
    price: 1499,
    image: "https://cdn.uc.assets.prezly.com/6120e22d-642b-41ba-9ace-624059cd9b11/-/format/auto/Groundnut%20pic-final.jpg",
    category: "seeds"
  },
  {
    id: 14,
    name: "Green Gram seeds",
    description: "best quality Green gram seeds for high quality",
    price: 499,
    image: "https://badikheti-production.s3.ap-south-1.amazonaws.com/products/20220209170320607851771.jpg?tr=w-216,h-288",
    category: "seeds"
  },
  {
    id: 15,
    name: "Bengal Gram seeds",
    description: "best quality Bengal gram seeds for high quality",
    price: 399,
    image: "https://ankurseeds.com/storage/upload/products_images/gram-jaki-9218.jpg",
    category: "seeds"
  },
  {
    id: 16,
    name: "Black gram seeds",
    description: "best quality Black gram seeds for high quality",
    price: 499,
    image: "https://badikheti-production.s3.ap-south-1.amazonaws.com/products/202205311459551949435974.jpg",
    category: "seeds"
  },
  {
    id: 17,
    name: "Pumpkin seeds",
    description: "best quality pumpkin  seeds for high quality",
    price: 699,
    image: "https://www.agiboo.com/wp-content/uploads/2021/01/pumpkin-seeds-were-poured-from-sack-ground.jpg",
    category: "seeds"
  },
  {
    id: 18,
    name: "Water melon seeds",
    description: "best quality Water melon seeds for high quality",
    price: 499,
    image: "https://femina.wwmindia.com/thumb/content/2020/feb/watermelon-seeds-01-thumb1582265978.jpg?width=1280&height=720",
    category: "seeds"
  },
  {
    id: 19,
    name: "chia seeds",
    description: "best quality organic chia  seeds for high quality",
    price: 799,
    image: "https://m.media-amazon.com/images/I/71KIoiGwSdL.jpg",
    category: "seeds"
  },
  {
    id: 20,
    name: "Pea seeds",
    description: "best quality pea seeds for high quality",
    price: 1499,
    image: "https://m.media-amazon.com/images/I/61HKPF3f9YL._AC_UF1000,1000_QL80_.jpg",
    category: "seeds"
  },
  {
    id: 21,
    name: "IPL-Indian pest lest",
    description: "fertilizer for better growth",
    price: 1499,
    image: "https://www.indianpotash.org/images/prod7.jpg?1741392000022",
    category: "fertilizers"
  },
  {
    id: 22,
    name: "DAP",
    description: "fertilizer for better growth",
    price: 1299,
    image: "https://www.indianpotash.org/images/prod_sop.jpg?1741392000017",
    category: "fertilizers"
  },
  {
    id: 23,
    name: "SSP+",
    description: "fertilizer for better growth",
    price: 1499,
    image: "https://5.imimg.com/data5/SELLER/Default/2024/4/407725582/UT/LH/RI/152264174/mono-ssp-plus-fertilizer-500x500.jpg",
    category: "fertilizers"
  },
  {
    id: 24,
    name: "UREA",
    description: "fertilizer for better growth",
    price: 1099,
    image: "https://iffco-public-assets.s3.ap-south-1.amazonaws.com/s3fs-public/2020-04/UREA_0.png",
    category: "fertilizers"
  },
  {
    id: 25,
    name: "Grow More",
    description: "fertilizer for better growth",
    price: 1699,
    image: "https://5.imimg.com/data5/SELLER/Default/2023/3/296100423/MG/ZP/IR/160961088/grow-more-fertilizer.jpeg",
    category: "fertilizers"
  },
  {
    id: 26,
    name: "Garden Tool Kit",
    description: "Complete set of essential gardening tools",
    price: 1499,
    image: "https://images.meesho.com/images/products/399538784/xj1cn_512.webp",
    category: "tools"
  },
  {
    id: 27,
    name: "organic grow more",
    description: "fertilizer for better growth",
    price: 1699,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShrp0ZDKGogCGju9NIfj0oh3KqiRYMR0wJtg&s",
    category: "fertilizers"
  },
   {
    id: 28,
    name: "Beans seeds",
    description: "premium seeds beans for better growth",
    price: 199,
    image: "https://rukminim2.flixcart.com/image/850/1000/ktbu6q80/plant-seed/a/h/v/500-organic-green-long-bean-seeds-qualtivate-original-imag6p3dkhs7db3j.jpeg?q=90&crop=false",
    category: "seeds"
  },
  
] as const;