import React from 'react';
import { X, MessageCircle } from 'lucide-react';

interface CustomerSupportProps {
  onClose: () => void;
}

function CustomerSupport({ onClose }: CustomerSupportProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Customer Support</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <div className="text-center space-y-4">
          <MessageCircle className="h-16 w-16 mx-auto text-green-600" />
          <p className="text-gray-600">
            Our support team is here to help! Send us a message through our chat system and we'll get back to you as soon as possible.
          </p>
          <button
            className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700"
            onClick={() => {
              // Here you would typically integrate with a chat system
              alert('Chat feature coming soon!');
            }}
          >
            Start Chat
          </button>
        </div>
      </div>
    </div>
  );
}

export default CustomerSupport;