import React, { useState } from 'react';
import { X } from 'lucide-react';

interface CartProps {
  items: Array<{ id: number; name: string; price: number; quantity: number }>;
  onClose: () => void;
  setCart: React.Dispatch<React.SetStateAction<Array<{ id: number; name: string; price: number; quantity: number }>>>;
}

function Cart({ items, onClose, setCart }: CartProps) {
  const [showAddress, setShowAddress] = useState(false);
  const [address, setAddress] = useState('');
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [isPayLater, setIsPayLater] = useState(false);
  const [idProof, setIdProof] = useState('');
  const [idProofNumber, setIdProofNumber] = useState('');

  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const interestAmount = isPayLater ? total * 0.05 : 0;
  const finalAmount = total + interestAmount;

  const handlePayment = (payLater: boolean) => {
    setIsPayLater(payLater);
    setShowAddress(true);
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (isPayLater && (!idProof || !idProofNumber)) {
      alert('Please provide ID proof details for Pay Later option');
      return;
    }
    setOrderSuccess(true);
    setCart([]);
  };

  const getDeliveryDate = () => {
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + 4);
    return deliveryDate.toLocaleDateString('en-IN', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (orderSuccess) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white p-8 rounded-lg max-w-md w-full">
          <h2 className="text-2xl font-bold text-green-600 mb-4">Order Successful!</h2>
          <div className="space-y-4">
            <p className="text-gray-600">Thank you for shopping with AGRIHUB.</p>
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <p className="text-green-800">
                Your order will be delivered by:
                <span className="block font-semibold mt-1">{getDeliveryDate()}</span>
              </p>
              <p className="text-sm text-green-700 mt-2">
                (Estimated delivery time: 4 days from order date)
              </p>
            </div>
            {isPayLater && (
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mt-4">
                <p className="text-blue-800">
                  Pay Later Amount Details:
                  <span className="block font-semibold mt-1">
                    Original Amount: ₹{total}
                    <br />
                    Interest (5%): ₹{interestAmount}
                    <br />
                    Total Amount: ₹{finalAmount}
                  </span>
                </p>
              </div>
            )}
          </div>
          <button
            onClick={onClose}
            className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 mt-6"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Your Cart</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        {items.length === 0 ? (
          <p className="text-gray-500 text-center py-4">Your cart is empty</p>
        ) : (
          <>
            <div className="space-y-4 mb-6">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between items-center border-b pb-4">
                  <div>
                    <h3 className="font-semibold">{item.name}</h3>
                    <p className="text-gray-600">₹{item.price} × {item.quantity}</p>
                  </div>
                  <span className="font-bold">₹{item.price * item.quantity}</span>
                </div>
              ))}
            </div>

            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-6">
                <span className="text-xl font-bold">Total:</span>
                <span className="text-xl font-bold">₹{total}</span>
              </div>

              {!showAddress ? (
                <div className="flex space-x-4">
                  <button
                    onClick={() => handlePayment(false)}
                    className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700"
                  >
                    Pay Now
                  </button>
                  <button
                    onClick={() => handlePayment(true)}
                    className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
                  >
                    Pay Later
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmitOrder} className="space-y-4">
                  {isPayLater && (
                    <>
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <p className="text-blue-800 mb-2">Pay Later Details:</p>
                        <p className="text-sm text-blue-600">
                          Original Amount: ₹{total}
                          <br />
                          Interest (5%): ₹{interestAmount}
                          <br />
                          Total Amount: ₹{finalAmount}
                        </p>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <label htmlFor="idProof" className="block text-gray-700 font-medium mb-2">
                            Select ID Proof Type
                          </label>
                          <select
                            id="idProof"
                            value={idProof}
                            onChange={(e) => setIdProof(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                            required
                          >
                            <option value="">Select ID Type</option>
                            <option value="aadhar">Aadhar Card</option>
                            <option value="pan">PAN Card</option>
                          </select>
                        </div>
                        <div>
                          <label htmlFor="idProofNumber" className="block text-gray-700 font-medium mb-2">
                            ID Number
                          </label>
                          <input
                            type="text"
                            id="idProofNumber"
                            value={idProofNumber}
                            onChange={(e) => setIdProofNumber(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                            placeholder={idProof === 'aadhar' ? 'Enter 12-digit Aadhar number' : 'Enter 10-digit PAN number'}
                            required
                          />
                        </div>
                      </div>
                    </>
                  )}
                  <div>
                    <label htmlFor="address" className="block text-gray-700 font-medium mb-2">
                      Delivery Address
                    </label>
                    <textarea
                      id="address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                      rows={4}
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700"
                  >
                    Confirm Order
                  </button>
                </form>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default Cart;